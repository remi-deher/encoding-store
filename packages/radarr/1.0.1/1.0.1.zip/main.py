import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import plugin
raise SystemExit(plugin.main([plugin.__file__, 'radarr']))
